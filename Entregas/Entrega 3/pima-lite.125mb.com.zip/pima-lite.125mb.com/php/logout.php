<?php
 //Se inicia la sesion
  session_start();
 // Se quita la sesion
  session_unset();
 // Se destuye la sesion
  session_destroy();
 // Se redirecciona a una pagina
  header('Location: /php');
?>

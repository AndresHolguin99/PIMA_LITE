<?php
//Ver si la sesión existe
  session_start();
//Importar la conexión con la base de datos
  require 'database.php';
//Si existe la conexión
  if (isset($_SESSION['user_id'])) {
// Se consultan los datos del usuario
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
// Se vinculan los datos
    $records->bindParam(':id', $_SESSION['user_id']);
// Se ejecutan los resultados
    $records->execute();
// Se almacenan los resultados
    $results = $records->fetch(PDO::FETCH_ASSOC);
// Se crea una variable
    $user = null;
// Se guardan los resultados en la variable
    if (count($results) > 0) {
      $user = $results;
    }
  }
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>PIMA Lite</title>

		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="/images/fav-icon/icon.png">


		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="/css/style.css">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="/css/responsive.css">


		<!-- Fix Internet Explorer ______________________________________-->

		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
			<script src="vendor/respond.js"></script>
		<![endif]-->
			
	</head>

	<body>
		<div class="main-page-wrapper">



			<!-- 
			=============================================
				Encabezado
			============================================== 
			-->
			<header class="theme-main-header">
				<div class="container">
					<a href="index.html" class="logo float-left tran4s"><img src="/images/logo/logo.png" alt="Logo"></a>
					
					<!-- ========================= Theme Feature Page Menu ======================= -->
					<nav class="navbar float-right theme-main-menu one-page-menu">
					   <!-- Brand and toggle get grouped for better mobile display -->
					   <div class="navbar-header">
					     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
					       <span class="sr-only">Toggle navigation</span>
					       Menu
					       <i class="fa fa-bars" aria-hidden="true"></i>
					     </button>
					   </div>
					   <!-- Collect the nav links, forms, and other content for toggling -->
					   <div class="collapse navbar-collapse" id="navbar-collapse-1">
					     <ul class="nav navbar-nav">
					       	<li class="active"><a href="#home">HOME</a></li>
							<li><a href="#about-us">¿QUÉ ES?</a></li>
							<li><a href="#service-section">SERVICIOS</a></li>
							<li><a href="#project-section">SISTEMA</a></li>
							<li><a href="#team-section">EQUIPO</a></li>
							<li><a href="#our-client">THINGSPEAK</a></li>
							<li><a href="#datos">DATOS</a></li>
                                                        <li><a href="#tendencias">TENDENCIAS</a></li>
							<li><a href="#contact-section">CONTACT</a></li>
                                                        
                                                        <?php if(!empty($user)): ?>

                                                        <li><a href="logout.php">LOGOUT</a></li>
                                                     
                                                      
                                                       <?php else: ?>
                                                       <li><a href="login.php">LOGIN</a></li>
                                                       
                                                       <?php endif; ?>
					     </ul>
					   </div><!-- /.navbar-collapse -->
					</nav> <!-- /.theme-feature-menu -->
				</div>
			</header> <!-- /.theme-main-header -->


			<!--
			=====================================================
				Theme Main SLider
			=====================================================
			-->
			<div id="home" class="banner">
	        	<div class="rev_slider_wrapper">
					<!-- START REVOLUTION SLIDER 5.0.7 auto mode -->
						<div id="main-banner-slider" class="rev_slider video-slider" data-version="5.0.7">
							<ul>

								<!-- SLIDE1  -->
								<li data-index="rs-280" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default"  data-title="Title Goes Here" data-description="">
									<!-- MAIN IMAGE -->
									<img src="/images/home/slide-1.jpg"  alt="image" class="rev-slidebg" data-bgparallax="3" data-bgposition="center center" data-duration="20000" data-ease="Linear.easeNone" data-kenburns="on" data-no-retina="" data-offsetend="0 0" data-offsetstart="0 0" data-rotateend="0" data-rotatestart="0" data-scaleend="100" data-scalestart="140">
									<!-- LAYERS -->

									<!-- LAYER NR. 1 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-58','-58','0','-50']" 
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="1000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h1>BIENVENIDO</h1>
									</div>

									<!-- LAYER NR. 2 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-05','-05','63','0']"
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="2000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h6>Gracias por confiar en nosotros</h6>
									</div>


									<!-- LAYER NR. 3 -->
									<div class="tp-caption"
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['52','52','125','80']"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="3000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on">
										<a href="contact-us.html" class="project-button hvr-bounce-to-right">Conocenos.</a>
									</div>
								
								</li>


								<!-- SLIDE2  -->
								<li data-index="rs-20" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="video/drinkwinecover.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Title Goes Here" data-description="">
									<!-- MAIN IMAGE -->
									<img src="/video/drinkwinecover.jpg"  alt="image" class="rev-slidebg" data-bgparallax="3" data-bgposition="center center" data-duration="20000" data-ease="Linear.easeNone" data-kenburns="on" data-no-retina="" data-offsetend="0 0" data-offsetstart="0 0" data-rotateend="0" data-rotatestart="0" data-scaleend="100" data-scalestart="140">
									<!-- LAYERS -->

									<!-- BACKGROUND VIDEO LAYER -->
									<div class="rs-background-video-layer" 
										data-forcerewind="on" 
										data-volume="mute" 
										data-videowidth="100%" 
										data-videoheight="100%" 
										data-videomp4="video/Drink-Wine.mp4" 
										data-videopreload="preload" 
										data-videoloop="loopandnoslidestop" 
										data-forceCover="1" 
										data-aspectratio="16:9" 
										data-autoplay="true" 
										data-autoplayonlyfirsttime="false" 
										data-nextslideatend="true" 
									></div>

									<!-- LAYER NR. 1 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-58','-33','-33','-100']" 
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="1000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h1>Esto es PIMA Lite</h1>
									</div>

									<!-- LAYER NR. 2 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-05','93','93','20']"
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="2000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h6>Tu mejor desición</h6>
									</div>


									<!-- LAYER NR. 3 -->
									<div class="tp-caption"
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['52','185','185','105']"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="3000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on">
										<a href="contact-us.html" class="project-button hvr-bounce-to-right">Conocenos</a>
									</div>
								</li>

								<!-- SLIDE3  -->
								<li data-index="rs-18" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/home/slide-2.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Title Goes Here" data-description="">
									<!-- MAIN IMAGE -->
									<img src="/images/home/slide-2.jpg"  alt="image" class="rev-slidebg" data-bgparallax="3" data-bgposition="center center" data-duration="20000" data-ease="Linear.easeNone" data-kenburns="on" data-no-retina="" data-offsetend="0 0" data-offsetstart="0 0" data-rotateend="0" data-rotatestart="0" data-scaleend="100" data-scalestart="140">
									<!-- LAYERS -->

									<!-- LAYER NR. 1 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-58','-33','-33','-100']" 
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="1000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h1>Somos PIMA Lite</h1>
									</div>

									<!-- LAYER NR. 2 -->
									<div class="tp-caption" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-05','93','93','20']"
										data-width="none"
										data-height="none"
										data-whitespace="nowrap"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="2000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on" 
										style="z-index: 6; white-space: nowrap;">
										<h6>Piensa en verde</h6>
									</div>


									<!-- LAYER NR. 3 -->
									<div class="tp-caption"
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['52','185','185','105']"
										data-transform_idle="o:1;"
							 
										data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
										data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
										data-mask_in="x:0px;y:[100%];" 
										data-mask_out="x:inherit;y:inherit;" 
										data-start="3000" 
										data-splitin="none" 
										data-splitout="none" 
										data-responsive_offset="on">
										<a href="contact-us.html" class="project-button hvr-bounce-to-right">Conocenos</a>
									</div>
								</li>
							</ul>	
						</div>
					</div><!-- END REVOLUTION SLIDER -->
	        </div> <!--  /#banner -->

                        <!--
			=====================================================
				Datos
			=====================================================
			-->
			<section id="datos">
				<div class="container">
					<div class="theme-title">
						<h2>Datos generados</h2>
						<p>Se mostrarán los datos obtenidos tras realizar una analitica basica para los datos.</p>
					</div> <!-- /.theme-title -->

					<div class="row">
                                                <div class="col-sm">
                                                  <div>
                                                   <br> <br>
                                                    <h6><center>Temperatura</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1570386/charts/1?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Promedio+Temperatura&type=line&xaxis=Tiempo&yaxis=Temperatura"></iframe>
                                                    </center>
                                                  </div>
                                                </div>
                                                <div class="col-sm">
                                                  <div>
                                                    <br> <br>
                                                    <h6><center>Humedad</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1570386/charts/2?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Promedio+de+Humedad&type=line&xaxis=Tiempo&yaxis=Humedad"></iframe>
                                                    </center>
                                                  </div>
                                                </div> 
                                                <div class="col-sm">
                                                  <div>
                                                    <br> <br>
                                                    <h6><center>Metano</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1570386/charts/3?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Promedio+Metano&type=line&xaxis=Tiempo&yaxis=Metano"></iframe>
                                                    </center>
                                                  </div>
                                                </div> 
                                                <div class="col-sm">
                                                  <div>
                                                    <br> <br>
                                                    <h6><center>Monoxido</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1570386/charts/4?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Promedio+Mon%C3%B3xido+de+carbono&type=line&xaxis=Tiempo&yaxis=Mon%C3%B3xido"></iframe>
                                                    </center>
                                                  </div>
                                                </div> 
                                                 					
					</div> <!-- /.row -->
				</div> <!-- /.container -->
			</section> <!-- /#about-us -->
                        <!--
			=====================================================
				Tendencias
			=====================================================
			-->
			<section id="tendencias">
				<div class="container">
					<div class="theme-title">
						<h2>Tendencias - Contaminantes</h2>
						<p>Se mostrarán las tendencias obtenidas al realizar las regresiones lineales para cada uno de los contaminantes.</p>
					</div> <!-- /.theme-title -->

					<div class="row">
                                                <div class="col-sm">
                                                  <div>
                                                    <br> <br>
                                                    <h6><center>Monóxido de carbono</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1559284/charts/1?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Regresi%C3%B3n+para+el+mon%C3%B3xido+de+carbono&type=spline&xaxis=Muestras"></iframe>
                                                    </center>
                                                  </div>
                                                </div>
                                                <div class="col-sm">
                                                  <div>
                                                    <br> <br>
                                                    <h6><center>Metano</center></h6>
                                                    <center>
                                                    <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1574509/charts/1?bgcolor=%23ffffff&color=%232920d6&dynamic=true&results=60&title=Regresi%C3%B3n+para+el+metano&type=line&yaxis=Muestras"></iframe>
                                                    </center>
                                                  </div>
                                                </div> 				
					</div> <!-- /.row -->
				</div> <!-- /.container -->
			</section> <!-- /#about-us -->

	        <!--
			=====================================================
				¿Qué es?
			=====================================================
			-->
			<section id="about-us">
				<div class="container">
					<div class="theme-title">
						<h2>¿QUÉ ES?</h2>
						<p>PIMA Lite es un sistema que brinda la posibilidad de conocer la calidad del aire en algunas zonas de Bogotá, permite de forma sencilla y cómoda visualizar datos y gráficos gracias a sensores electrónicos que establecen variaciones de los contaminantes como temperatura y humedad, dióxido de carbono y metano.</p>
					</div> <!-- /.theme-title -->

					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-6">
							<div class="single-about-content">
								<div class="icon round-border tran3s">
									<i class="fa fa-trophy" aria-hidden="true"></i>
								</div>
								<h5><a href="#" class="tran3s">DISEÑO</a></h5>
								<p>Altos estandares de calidad que permite obtener datos y gráficos eficientemente.</p>
								<a href="#" class="more tran3s hvr-bounce-to-right">Más detalles</a>
							</div> <!-- /.single-about-content -->
						</div> <!-- /.col -->

						<div class="col-lg-3 col-md-3 col-sm-6">
							<div class="single-about-content">
								<div class="icon round-border tran3s">
									<i class="far fa-laptop" aria-hidden="true"></i>
								</div>
								<h5><a href="#" class="tran3s">PLACA MADRE</a></h5>
								<p>Desarrollado con la mejor tecnología como lo es Raspberry Pi 3, capaz de realizar tareas mas comunes de un ordenador.</p>
								<a href="#" class="more tran3s hvr-bounce-to-right">Más detalles</a>
							</div> <!-- /.single-about-content -->
						</div> <!-- /.col -->

						<div class="col-lg-3 col-md-3 col-sm-6">
							<div class="single-about-content">
								<div class="icon round-border tran3s">
									<i class="fa fa-cloud" aria-hidden="true"></i>
								</div>
								<h5><a href="#" class="tran3s">Nube</a></h5>
								<p>Guarda de manera segura tus datos, gráficos, archivos y mucho más en la nube</p>
								<a href="#" class="more tran3s hvr-bounce-to-right">Más detalles</a>
							</div> <!-- /.single-about-content -->
						</div> <!-- /.col -->

						<div class="col-lg-3 col-md-3 col-sm-6">
							<div class="single-about-content">
								<div class="icon round-border tran3s">
									<i class="fa fa-mobile" aria-hidden="true"></i>
								</div>
								<h5><a href="#" class="tran3s">Sensores</a></h5>
								<p>Sensor de temperatura y Humedad DHT11, Sensor MQ-7 Monóxido de carbono, Sensor MQ-4 Gas metano.</p>
								<a href="#" class="more tran3s hvr-bounce-to-right">Más detalles</a>
							</div> <!-- /.single-about-content -->
						</div> <!-- /.col -->
					</div> <!-- /.row -->
				</div> <!-- /.container -->
			</section> <!-- /#about-us -->


			<!--
			=====================================================
				Servicios
			=====================================================
			-->
			<div id="service-section">
				<div class="container">
					<div class="theme-title">
						<h2>SERVICIOS</h2>
						<p>No queremos forzar nuestras ideas en los clientes, sino simplemente hacer lo que desean.</p>
					</div> <!-- /.theme-title -->

					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-trophy" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">Diseño</a></h6>
								</div>
								<p>Un sistema que conoce la calidad del aire que permite de forma sencilla y cómoda visualizar datos que establecen variaciones de los contaminantes como temperatura y humedad, dióxido de carbono y metano. </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->

						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-laptop" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">Placa Madre</a></h6>
								</div>
								<p>La Raspberry Pi es la placa de un ordenador simple compuesto por un SoC, CPU, memoria RAM, puertos de entrada y salida de audio y vídeo, conectividad de red, ranura SD para almacenamiento, reloj… </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->

						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-cloud" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">Nube</a></h6>
								</div>
								<p>Los datos son almacenados en un servidor en la nube (ThingSpeak) garantizando fiabilidad y seguridad, con excelente transmisión de datos y así permitir al lector la correcta presentación de estos gráficamente. </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->

						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-mobile" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">Sensores</a></h6>
								</div>
								<p>Sensores de alta calidad y precisión como lo son sensor de temperatura y Humedad DHT11, Sensor MQ-7 Monóxido de carbono, Sensor MQ-4 Gas metano, que aportan a la alta seguridad del lugar que te rodea. </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->

						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-anchor" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">Soporte</a></h6>
								</div>
								<p>La garantía del ordenador incluye soporte técnico gratuito durante 6 meses. Nuestro equipo te asegura la mejor atención para que nunca tengas inconvenientes con ningún producto. </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->

						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="single-service-content">
								<div class="icon-heading tran3s">
									<div class="icon tran3s"><i class="fa fa-bookmark" aria-hidden="true"></i></div>
									<h6><a href="#" class="tran3s">         </a></h6>
								</div>
								<p>                                                                                                                                                                                                                    </p>
							</div> <!-- /.single-service-content -->
						</div> <!-- /.col-lg -->
					</div> <!-- /.row -->
				</div> <!-- /.container -->
			</div> <!-- /#service-section -->



			<!--
			=====================================================
				Project Section
			=====================================================
			-->
			<div id="project-section">
				<div class="container">
					<div class="theme-title">
						<h2>NUESTRO SISTEMA</h2>
						<p>PIME Lite, sabemos lo que hacemos. </p>
					</div> <!-- /.theme-title -->

					<div class="project-menu">
						<ul>
	        				<li class="filter active tran3s" data-filter="all">All</li>
							<li class="filter tran3s" data-filter=".web">Diseño</li>
							<li class="filter tran3s" data-filter=".photo">Placa Madre</li>
							<li class="filter tran3s" data-filter=".webd">Nube</li>
							<li class="filter tran3s" data-filter=".om">Sensores</li>
							<li class="filter tran3s" data-filter=".dmedia">Datos</li>
							<li class="filter tran3s" data-filter=".support">Soporte</li>
	        			</ul>
					</div>

					<div class="project-gallery clear-fix">
						<div class="mix grid-item web">
							<div class="single-img">
								<img src="/images/project/diagramabajonivel.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Diagrama de bloques </a></h6>
										<ul>
											<li>Entradas /</li>
											<li>Salidas /</li>
											<li>Procesamiento /</li>
											<li>Pagina web</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item web">
							<div class="single-img">
								<img src="/images/project/diagrama.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Arquitecura General</a></h6>
										<ul>
											<li>Entorno en donde se puede implementar el sistema/</li>
											<li>Aplicación /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item web">
							<div class="single-img">
								<img src="/images/project/esquematico.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Esquematico</a></h6>
										<ul>
											<li>Conexiones generales /</li>
											<li>Implementación del sistema /</li>
											<li>Componentes /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item photo">
							<div class="single-img">
								<img src="/images/project/raspberry.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Tarjeta de desarrollo</a></h6>
										<ul>
											<li>Raspberry PI</li>
											
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item webd">
							<div class="single-img">
								<img src="/images/project/thinkspace.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Dashboard</a></h6>
										<ul>
											<li>Definición de variables /</li>
											<li>Establecimiento de espacios /</li>
											<li>Flexibilidad /</li>
											
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item om">
							<div class="single-img">
								<img src="/images/project/carbono.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Sensor de monoxido carbono</a></h6>
										<ul>
											<li>Medición /</li>
											<li>MQ-7 /</li>
											
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item om">
							<div class="single-img">
								<img src="/images/project/metano.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Sensor de metano</a></h6>
										<ul>
											<li>Medición /</li>
											<li>MQ-4 /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item om">
							<div class="single-img">
								<img src="/images/project/temperatura.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Sensor de humedad</a></h6>
										<ul>
											<li>Medición /</li>
											<li>DHT-11 /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item dmedia">
							<div class="single-img">
								<img src="/images/project/graficos.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Datos por variable</a></h6>
										<ul>
											<li>Contaminantes /</li>
											<li>Humedad /</li>
											<li>Temperatura /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

						<div class="mix grid-item dmedia">
							<div class="single-img">
								<img src="/images/project/timestap.jpg" alt="Image">
								<div class="opacity">
									<div class="border-shape"><div><div>
										<h6><a href="#">Datos por tiempo</a></h6>
										<ul>
											<li>Registro /</li>
											<li>Historial /</li>
										</ul></div></div>
									</div> <!-- /.border-shape -->
								</div> <!-- /.opacity -->
							</div> <!-- /.single-img -->
						</div> <!-- /.grid-item -->

					</div> <!-- /.project-gallery -->
				</div> <!-- /.container -->
			</div> <!-- /#project-section -->

			<!--
			=====================================================
				Page middle banner
			=====================================================
			-->

			<div class="page-middle-banner">
				<div class="opacity">
					<h3>Somos ambiente <span class="p-color">&amp;</span> Somos PIMA Lite</h3>
					<a href="#" class="hvr-bounce-to-right">Conócenos</a>
				</div> <!-- /.opacity -->
			</div> <!-- /.page-middle-banner -->


			<!--
			=====================================================
				Team Section
			=====================================================
			-->
			<div id="team-section">
				<div class="container">
					<div class="theme-title">
						<h2>Nuestro equipo</h2>
						<p> Ingenieros Electrónicos de la Pontificia Universidad Javeriana, especializados en el enfasis de IOT. </p>
					</div> <!-- /.theme-title -->

					<div class="clear-fix team-member-wrapper">
						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="/images/team/1.jpg" alt="Image">
									<div class="opacity tran4s">
										<h4>Juan Andrés Holguín</h4>
										<span>Ingeniero Electrónico</span>
										<p>Ingeniero Electrónico con énfasis en IOT, diseño de hardware y software. Soy una persona comprometida y capaz de trabajar en equipo; hábil en la atención de detalle.</p>
									</div>
								</div> <!-- /.img -->
								<div class="member-name">
									<h6>Juan Andrés Holguín</h6>
									<p>Ingeniero Electrónico</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->

						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="/images/team/2.jpg" alt="Image">
									<div class="opacity tran4s">
										<h4>Marcos Sebastían Andrade</h4>
										<span>Ingeniero Electrónico</span>
										<p>Ingeniero Electrónico con énfasis en IOT, diseño de hardware y software. Soy una persona comprometida y capaz de trabajar en equipo; hábil en la atención de detalle.</p>
									</div>
								</div> <!-- /.img -->
								<div class="member-name">
									<h6>Marcos Sebastían Andrade</h6>
									<p>Ingeniero Electrónico</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->

						<div class="float-left">
							<div class="single-team-member">
								<div class="img">
									<img src="/images/team/3.jpg" alt="Image">
									<div class="opacity tran4s">
										<h4>Miguel Ernesto Figueroa</h4>
										<span>Ingeniero Electrónico</span>
										<p>Ingeniero Electrónico con énfasis en IOT, diseño de hardware y software. Soy una persona comprometida y capaz de trabajar en equipo; hábil en la atención de detalle.</p>
									</div>
								</div> <!-- /.img -->
								<div class="member-name">
									<h6>Miguel Ernesto Figueroa</h6>
									<p>Ingeniero Electrónico</p>
									<ul>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div> <!-- /.member-name -->
							</div> <!-- /.single-team-member -->
						</div> <!-- /float-left -->
					</div> <!-- /.team-member-wrapper -->
				</div> <!-- /.conatiner -->
			</div> <!-- /#team-section -->



			<!--
			=====================================================
				THINGSPEAK
			=====================================================
			-->
			<div id="our-client">
				<div class="container">
					<div class="theme-title">
						<h2>THINGSPEAK</h2>
						<p>ThingSpeak es una herramienta de visualización, comunicación y conexión a internet bastante útil, sobre la cual se configuran  .</p>
					</div> <!-- /.theme-title -->

					<div class="client-slider">
						<div class="item">
							<img src="/images/project/graficos.jpg" alt="Client">
							<p>Desde los diferentes sensores mencionados anteriormente se hace la obtención de las variables ambientales de interés para ser procesadas en la tarjeta Raspberry Pi 3, la cual se encarga de enviar dicha información a la plataforma ThingSpeak a tráves de Paho y la tecnología MQTT. De tal forma que se puede apreciar cada variable enviada en su canal y visualización respectiva.</p>
							<h6>- Visualización privada de los canales </h6>
						</div> <!-- /.item -->
						<div class="item">
							<img src="/images/project/timestap.jpg" alt="Client">
							<p>Desde la tarjeta Raspberry Pi 3 se envía la información relacionada al tiempo de medición y envío de los datos de los sensores, permitiendo conocer la marca temporal de los datos medidos (Timestamp).</p>
							<h6>- Visualización privada del canal exclusivo "Timestamp" -</h6>
						</div> <!-- /.item -->
					</div> <!-- /.client-slider -->
				</div> <!-- /.container -->
			</div> <!-- /#our-client -->

			

				<!--

			=====================================================
				Partner Section
			=====================================================
			-->
			<div id="partner-section">
				<div class="container">
					<div id="partner_logo" class="owl-carousel owl-theme">
						<div class="item"><img src="/images/logo/logo.png" alt="logo"></div>						
						<div class="item"><img src="/images/logo/logoiot.png" alt="logo"></div>
					</div> <!-- End .partner_logo -->
				</div> <!-- /.container -->
			</div> <!-- /#partner-section -->



			<!--
			=====================================================
				Contact Section
			=====================================================
			-->
			<div id="contact-section">
				<div class="container">
					<div class="clear-fix contact-address-content">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="left-side">
								<h2>Información de contacto</h2>
								<p>Somos un grupo de ingenieros Electrónicos de la Pontificia Universidad Javeriana especializados en el área de Internet de las cosas. <br><br>
								Somos imnovadores, eficientes con diseño de sistemas IOT de alta calidad.</p>

								<ul>
									<li>
										<div class="icon tran3s round-border p-color-bg"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
										<h6>Dirección</h6>
										<p>Pontificia Universidad Javeriana, Bogotá D.C., Colombia</p>
									</li>
									<li>
										<div class="icon tran3s round-border p-color-bg"><i class="fa fa-phone" aria-hidden="true"></i></div>
										<h6>Facultad de Ingeniería Electrónica</h6>
										<p>(1) 3208320</p>
									</li>
									<li>
										<div class="icon tran3s round-border p-color-bg"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
										<h6>Email</h6>
										<p>pima-lite@gmail.com</p>
									</li>
								</ul>
							</div> <!-- /.left-side -->
						</div> <!-- /.col- -->


						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="map-area">
								<h2>Locación</h2>
								<div id="map"></div>
							</div> <!-- /.map-area -->
						</div> <!-- /.col- -->
					</div> <!-- /.contact-address-content -->



					<!-- Contact Form -->
					<div class="send-message">
						<h2>Enviar mensaje</h2>

						<form action="inc/sendemail.php" class="form-validation" autocomplete="off" method="post">
							<div class="row">
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
									<div class="single-input">
										<input type="text" placeholder="First Name*" name="Fname">
									</div> <!-- /.single-input -->
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
									<div class="single-input">
										<input type="text" placeholder="Last Name*" name="Lname">
									</div> <!-- /.single-input -->
								</div>
								<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
									<div class="single-input">
										<input type="email" placeholder="Your Email*" name="email">
									</div> <!-- /.single-input -->
								</div>
							</div> <!-- /.row -->
							<div class="single-input">
								<input type="text" placeholder="Subject" name="sub">
							</div> <!-- /.single-input -->
							<textarea placeholder="Write Message" name="message"></textarea>


							<button class="tran3s p-color-bg">Send Message</button>
						</form>


						<!-- Contact Form Validation Markup -->
						<!-- Contact alert -->
						<div class="alert-wrapper" id="alert-success">
							<div id="success">
								<button class="closeAlert"><i class="fa fa-times" aria-hidden="true"></i></button>
								<div class="wrapper">
					               	<p>Your message was sent successfully.</p>
					             </div>
					        </div>
					    </div> <!-- End of .alert_wrapper -->
					    <div class="alert-wrapper" id="alert-error">
					        <div id="error">
					           	<button class="closeAlert"><i class="fa fa-times" aria-hidden="true"></i></button>
					           	<div class="wrapper">
					               	<p>Sorry!Something Went Wrong.</p>
					            </div>
					        </div>
					    </div> <!-- End of .alert_wrapper -->
					</div> <!-- /.send-message -->
				</div> <!-- /.container -->
			</div> <!-- /#contact-section -->



			<!--
			=====================================================
				PIE DE PAGINA
			=====================================================
			-->
			<footer>
				<div class="container">
					<a href="index.html" class="logo"><img src="images/logo/logo.png" alt="Logo"></a>

					<ul>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
					</ul>
					<p>Copyright @2018 All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
				</div>
			</footer>




			<!-- =============================================
				Loading Transition
			============================================== -->
			<div id="loader-wrapper">
				<div id="preloader_1">
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	                <span></span>
	            </div>
			</div>

			
	        <!-- Scroll Top Button -->
			<button class="scroll-top tran3s p-color-bg">
				<i class="fa fa-long-arrow-up" aria-hidden="true"></i>
			</button>




		<!-- Js File_________________________________ -->

		<!-- j Query -->
		<script type="text/javascript" src="/vendor/jquery.2.2.3.min.js"></script>

		<!-- Bootstrap JS -->
		<script type="text/javascript" src="/vendor/bootstrap/bootstrap.min.js"></script>

		<!-- Vendor js _________ -->
		
		<!-- revolution -->
		<script src="/vendor/revolution/jquery.themepunch.tools.min.js"></script>
		<script src="/vendor/revolution/jquery.themepunch.revolution.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="/vendor/revolution/revolution.extension.video.min.js"></script>

		<!-- Google map js -->
		<script async defer src="https://goo.gl/maps/LxpKF8f6fcDv4yQ57" type="text/javascript"></script> <!-- Gmap Helper -->
		<script src="vendor/gmaps.min.js"></script>
		<!-- owl.carousel -->
		<script type="text/javascript" src="/vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- mixitUp -->
		<script type="text/javascript" src="/vendor/jquery.mixitup.min.js"></script>
		<!-- Progress Bar js -->
		<script type="text/javascript" src="/vendor/skills-master/jquery.skills.js"></script>
		<!-- Validation -->
		<script type="text/javascript" src="/vendor/contact-form/validate.js"></script>
		<script type="text/javascript" src="/vendor/contact-form/jquery.form.js"></script>


		<!-- Theme js -->
		<script type="text/javascript" src="/js/theme.js"></script>
		<script type="text/javascript" src="/js/map-script.js"></script>

		</div> <!-- /.main-page-wrapper -->
	</body>
</html>
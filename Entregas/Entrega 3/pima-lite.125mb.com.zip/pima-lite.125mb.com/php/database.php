<?php
//Deinición de las variables de la base de datos 
$server = 'fdb31.125mb.com';
$username = '3934392_wpress29e89a1e';
$password = 'Iot2021-3';
$database = '3934392_wpress29e89a1e';


//Generando la conexión con la base de datos
try {
  $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
//Mostrar error si no se realizó la conexión
} catch (PDOException $e) {
//Concatenar con mostrar el mensaje en pantalla
  die('Connection Failed: ' . $e->getMessage());
}

?>

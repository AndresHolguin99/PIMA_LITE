<?php

  session_start();
  
  // Si ya está configurada la sesion
  if (isset($_SESSION['user_id'])) {
    header('Location: /php');
  }
  require 'database.php';
  // Si los campos no están vacios
  if (!empty($_POST['email']) && !empty($_POST['password'])) {
  // Ejecutar una consulta a la base de datos para seleccionar los datos el usuario
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE email = :email');
  // Vincular los parametros establecidos
    $records->bindParam(':email', $_POST['email']);
  // Ejecutar la consulta
    $records->execute();
  // Se obtienen los datos del usuario
    $results = $records->fetch(PDO::FETCH_ASSOC);
  // Se crea una variable mensaje
    $message = '';
  // Se realiza la verificación de los datos
    if (count($results) > 0 && password_verify($_POST['password'], $results['password'])) {
  // Se almacenan los datos 
      $_SESSION['user_id'] = $results['id'];
  // Se redirecciona a una pagina
      header("Location: /php");
    } else {
  // Si no coinciden los datos
      $message = 'No coinciden los datos ingresados.';
    }
  }

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <!–– Se llama la libreria con los estilos -->
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <!–– Se llama el css definido -->
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <!–– Se llama al archivo header -->
    <?php require 'partials/header.php' ?>
    <!-- Se mira la variable mensaje está vacia o no-->
    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <h1>Ingreso</h1>
    <span>/ <a href="signup.php">Registrarse</a></span>

    <form action="login.php" method="POST">
      <input name="email" type="text" placeholder="Ingresa tu correo">
      <input name="password" type="password" placeholder="Ingresa tu contraseña">
      <input type="submit" value="Ingresar">
    </form>
  </body>
</html>


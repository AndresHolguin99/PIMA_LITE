<header>
  <a href="/index.html" class="logo float-left tran4s"><img src="/images/logo/logo.png" alt="Logo"></a>
</header>

<?php

  //LLamar la base de datos
  require 'database.php';
  
  // Variable mensaje
  $message = '';

  // Si no están vacios los campos se puede continuar
  if (!empty($_POST['email']) && !empty($_POST['password'])) {
  // Insertar los datos en la base de datos
    $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
  // Se ejecutará a consulta sql
    $stmt = $conn->prepare($sql);
  // Vincular el usuario
    $stmt->bindParam(':email', $_POST['email']);
  // Cifrar la contraseña
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);
  // Confirmar el funcionamiento
    if ($stmt->execute()) {
      $message = 'Registrado correctamente';
    } else {
      $message = 'Vuelve a ingresar los datos';
    }
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>SignUp</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>

    <?php require 'partials/header.php' ?>
    <!-- Si no está vacio el mensaje se muestra el mensaje-->   
    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <h1>Registro</h1>
    <span>/ <a href="login.php">Ingresar</a></span>

    <form action="signup.php" method="POST">
      <input name="email" type="text" placeholder="Ingresa tu correo">
      <input name="password" type="password" placeholder="Ingresa tu contraseña">
      <input name="confirm_password" type="password" placeholder="Ingresa tu contraseña">
      <input type="submit" value="Submit">
    </form>

  </body>
</html>


